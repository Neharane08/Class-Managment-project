package JDBC.Project.ClassMngt.Controller;

import java.util.Scanner;

import JDBC.Project.com.java.Classroom.serviceImpleClassMangtSystem.ClassMangtSystemImpl;

public class MainClass {

	Scanner sc = new Scanner(System.in);

	public void showMenuBar() {
		ClassMangtSystemImpl classmgtsystem1 = new ClassMangtSystemImpl();

		while (true) {
			System.out.println("\t---------MENU---------");
			System.out.println("\t" + "1 Add CoursetoDatabase::");
			System.out.println("\t" + "2 Display CoursetoDatabase::");
			System.out.println("\t" + "3 Add FacultytoDatabase::");
			System.out.println("\t" + "4 Display FacultytoDatabase::");
			System.out.println("\t" + "5 Add BatchtoDatabase::");
			System.out.println("\t" + "6 Display BatchtoDatabase::");
			System.out.println("\t" + "7 Add StudenttoDatabase::");
			System.out.println("\t" + "8 Display StudenttoDatabase::");
			System.out.println("-------------EXIT-----------");
			int ch = sc.nextInt();

			switch (ch) {
			case 1:
				classmgtsystem1.addCoursetoDatabase();
				break;

			case 2:
				classmgtsystem1.displayCoursetoDatabase();
				break;

			case 3:
				classmgtsystem1.addFacultytoDatabase();
				break;

			case 4:
				classmgtsystem1.displayFacultytoDatabase();
				break;

			case 5:
				classmgtsystem1.addBatchtoDatabase();
				break;

			case 6:
				classmgtsystem1.displayBatchtoDatabase();
				break;

			case 7:
				classmgtsystem1.addStudenttoDatabase();
				break;

			case 8:
				classmgtsystem1.displayStudenttoDatabase();
				break;

			default:
				break;

			}
		}

	}

	public static void main(String[] args) {
		MainClass c = new MainClass();
		c.showMenuBar();
	}

}
