package JDBC.Project.com.java.Classroom.serviceImpleClassMangtSystem;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

import com.designpattern.MyConnections;

import JDBC.Project.Classmgt.Service.ClassMgtSystem;

public class ClassMangtSystemImpl implements ClassMgtSystem {

	Scanner sc = new Scanner(System.in);

	@Override
	public void addCoursetoDatabase() {
		// TODO Auto-generated method stub
		System.out.println("Add CoursetoDatabase()");
		Connection connection = null;
		PreparedStatement ps = null;
		try {
			System.out.println("How many course you want to add ");
			int n = sc.nextInt();
			connection = MyConnections.getConnection();

			String Sql = "insert into course values(?,?)";

			ps = connection.prepareStatement(Sql);

			for (int i = 0; i < n; i++) {
				System.out.println("Enter course id:");
				int cid = sc.nextInt();
				ps.setInt(1, cid);
				System.out.println("Enter course name:");
				String cname = sc.next();
				ps.setString(2, cname);
				ps.execute();

			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();

			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}

	}

	@Override
	public void displayCoursetoDatabase() {
		Connection connection = null;
		try {
			connection = MyConnections.getConnection();
			String sql = "Select * From course";
			Statement smt = connection.createStatement();
			ResultSet rs = smt.executeQuery(sql);
			System.out.println("Course id\tCourse Name");
			while (rs.next()) {
				System.out.println(rs.getInt(1) + "\t  " + rs.getString(2));

			}

			smt.close();
		} catch (Exception e) {
			System.out.println(e);
			System.out.println("End Display Course");
		}

	}

	@Override
	public void addFacultytoDatabase() {
		System.out.println("START_ addFacultytoDatabase");
		Connection connection = null;
		PreparedStatement ps = null;
		try {
			System.out.println("How many Faculty you want to add");
			int n = sc.nextInt();
			connection = MyConnections.getConnection();
			String sql = "insert into faculty values(?,?,?)";
			ps = connection.prepareStatement(sql);

			for (int i = 0; i < n; i++) {
				System.out.println("Enter Faculty id:");
				int fid = sc.nextInt();
				ps.setInt(1, fid);
				System.out.println("Enter Faculty Name:");
				String fname = sc.next();
				ps.setString(2, fname);

				displayCoursetoDatabase();
				System.out.println("Select above course id");
				int cid = sc.nextInt();
				ps.setInt(3, cid);
				ps.execute();

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("End add faculty to Database");
	}

	@Override
	public void displayFacultytoDatabase() {
		Connection connection = null;
		System.out.println("Faculty id\tFaculty Name\tCourse id\tCourse Name");
		try {
			connection = MyConnections.getConnection();
			String sql = "Select f.fid,f.fname,c.cid,c.cname from faculty f inner join course c on f.cid=c.cid";
			Statement smt = connection.createStatement();
			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				System.out.println(
						rs.getInt(1) + "\t " + rs.getString(2) + "\t" + rs.getInt(3) + "\t " + rs.getString(4));

			}
			smt.close();
		} catch (Exception e) {
			e.printStackTrace();

		}

	}

	@Override
	public void addBatchtoDatabase() {
		System.out.println("START_addBatchtoDatabase");
		Connection connection = null;
		PreparedStatement ps = null;
		try {
			System.out.println("How many batch you want to added:");
			int n = sc.nextInt();
			connection = MyConnections.getConnection();
			String sql = "insert into batch value(?,?,?)";
			ps = connection.prepareStatement(sql);

			for (int i = 0; i < n; i++) {
				System.out.println("Enter batch id:");
				int bid = sc.nextInt();
				ps.setInt(1, bid);
				System.out.println("Enter batch Name");
				String bname = sc.next();
				ps.setString(2, bname);
				displayFacultytoDatabase();

				System.out.println("Select above faculty id");
				int fid = sc.nextInt();
				ps.setInt(3, fid);
				ps.execute();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("End add batch to Database");

	}

	@Override
	public void displayBatchtoDatabase() {
		Connection connection = null;
		System.out.println("Batch id\tBatch Name\tFaculty id\tFaculty Name\tCourse id\tCourse Name");
		try {
			connection = MyConnections.getConnection();
			String sql = "Select b.bid,b.bname,f.fid,f.fname,c.cid,c.cname from batch b inner join faculty f on b.fid=f.fid inner join course c on f.cid=c.cid";
			Statement smt = connection.createStatement();
			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				System.out.println(rs.getInt(1) + "\t " + rs.getString(2) + " \t " + rs.getInt(3) + "\t"
						+ rs.getString(4) + "\t " + rs.getInt(5) + "\t " + rs.getString(6));
			}
			smt.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		System.out.println("End Display Batch");

	}

	@Override
	public void addStudenttoDatabase() {
		System.out.println("START_addStudent to Database()");
		Connection connection = null;
		PreparedStatement ps = null;
		try {
			System.out.println("How many student you want to added:");
			int n = sc.nextInt();
			connection = MyConnections.getConnection();
			String Sql = "insert into student1 value(?,?,?)";

			ps = connection.prepareStatement(Sql);

			for (int i = 0; i < n; i++) {
				System.out.println("Enter Student id");
				int fid = sc.nextInt();
				ps.setInt(1, fid);
				System.out.println("Enter Student name");
				String fname = sc.next();
				ps.setString(2, fname);

				displayBatchtoDatabase();
				System.out.println("Select above batch id");
				int bid = sc.nextInt();
				ps.setInt(3, bid);
				ps.execute();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("End add student to Database");

	}

	@Override
	public void displayStudenttoDatabase() {
		Connection connection = null;
		System.out.println(
				"Student id\tStudent Name\tBatch id\tBatch Name\tFaculty id\tFaculty Name\tCourse id\tCourse Name");
		try {
			connection = MyConnections.getConnection();
			String sql = "Select s.sid,s.sname,b.bid,b.bname,f.fid,f.fname,c.cid,c.cname from Student1 s inner join batch b on s.bid=b.bid inner join faculty f on b.fid=f.fid inner join course c on f.cid=c.cid";

			Statement smt = connection.createStatement();
			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				System.out.println(rs.getInt(1) + "\t " + rs.getString(2) + "\t  " + rs.getInt(3) + "\t "
						+ rs.getString(4) + "\t " + rs.getInt(5) + "\t " + rs.getString(6) + "\t " + rs.getInt(7) + "\t"
						+ rs.getString(8));
			}
			smt.close();

		} catch (Exception e) {
			System.out.println(e);

			System.out.println("End display batch");
		}
	}

}
