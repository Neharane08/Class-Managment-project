package JDBC.Project.Classmgt.Service;

public interface ClassMgtSystem {

	public void addCoursetoDatabase();

	public void displayCoursetoDatabase();

	public void addFacultytoDatabase();

	public void displayFacultytoDatabase();

	public void addBatchtoDatabase();

	public void displayBatchtoDatabase();

	public void addStudenttoDatabase();

	public void displayStudenttoDatabase();

}
