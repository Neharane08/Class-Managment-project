package com.designpattern;

import java.sql.Connection;
import java.sql.DriverManager;

import com.mysql.jdbc.CallableStatement;

public class MyConnections {

	public static Connection Connection = null;

	// ser, clone, multithreading
	private MyConnections() {

	}

	public static  Connection getConnection() {
		if (Connection == null) {
			try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/b21", "root", "root");
				return Connection;
			} catch (Exception e) {
				e.printStackTrace();
			}

			return Connection;

		}

		return Connection;
	}

}
