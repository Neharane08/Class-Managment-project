package com.jdbc.ps;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

import com.designpattern.MyConnections;

public class UpdateRecord {

	public static void main(String[] args) {
		try {
			Connection connection = MyConnections.getConnection();
			String sql = "update employee set ename= ? where eid = ? ";
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter name for update");
			String updateName = sc.next();
			System.out.println("Enter employee eid whose ename u want to update");
			int updateId = sc.nextInt();
			PreparedStatement ps = connection.prepareStatement(sql);
			ps.setString(1, updateName);
			ps.setInt(2, updateId);
			ps.executeUpdate();
			System.out.println("-----records updated-------");
			connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
