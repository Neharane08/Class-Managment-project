package com.jdbc.ps;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/b21", "root", "root");
			// eid,ename,address
			String sql = "insert into employee values(?,?,?)";
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter employee id");
			int id = sc.nextInt();
			System.out.println("Enter employee name");
			String name = sc.next();
			System.out.println("Enter employee address");
			String address = sc.next();
			PreparedStatement ps = connection.prepareStatement(sql);
			ps.setInt(1, id);
			ps.setString(2, name);
			ps.setString(3, address);
			ps.execute();
			//connection.close();
			System.out.println("sucess");
			connection.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
