package com.jdbcexample;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class SelectRecord {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/b21", "root", "root");
			String sql = "select * from employee";
			Statement smt = connection.createStatement();
			// smt.execute(sql);
			ResultSet rs = smt.executeQuery(sql);
			while (rs.next()) {
				System.out.println(rs.getInt("eid"));
				System.out.println(rs.getString("ename"));
				System.out.println(rs.getString("address"));
			}
			connection.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
