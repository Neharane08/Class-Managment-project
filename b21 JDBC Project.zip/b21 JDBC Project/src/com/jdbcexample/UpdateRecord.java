package com.jdbcexample;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class UpdateRecord {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/b21", "root", "root");
			String sql = "update employee set ename='Priya' where eid in(101 , 102)";
			Statement smt = connection.createStatement();
			int i = smt.executeUpdate(sql);
			System.out.println("Updated record count"+i);
			connection.close();
			System.out.println("record update-----");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
