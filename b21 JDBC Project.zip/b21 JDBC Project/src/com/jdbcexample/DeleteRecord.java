package com.jdbcexample;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class DeleteRecord {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/b21", "root", "root");
			String sql = "Delete from employee where eid =102";
			Statement smt = connection.createStatement();
			smt.execute(sql);
			connection.close();
			System.out.println("record deleted-----");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
