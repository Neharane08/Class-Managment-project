package com.jdbcexample;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Test {

	public static void main(String[] args) {
		try {
			// step 1---driver load
			Class.forName("com.mysql.jdbc.Driver");
			// step 2---create the connections
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/b21", "root", "root");

			// step 3---build sql query
			String sql = "insert into Student values(11, 'Swami')";

			// step 4---create the statement
			Statement smt = connection.createStatement();
			// step 5---execute the sql quries
			smt.execute(sql);
			// step 6---
			connection.close();
			System.out.println("Record insert-----");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
