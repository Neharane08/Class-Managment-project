package com.callableStatement;

import java.sql.CallableStatement;
import java.sql.Connection;

import com.designpattern.MyConnections;

public class CallableStatement1 {

	public static void main(String[] args) {
		try {
			Connection connection = MyConnections.getConnection();

			CallableStatement cs = connection.prepareCall("{call get_merit_student(?,?)}");
			cs.setInt(1, 225);
			cs.setString(2, "ABC");
			cs.execute();
			System.out.println("Records inserted------");
            connection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
